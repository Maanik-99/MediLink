# MediLink - Healthcare Management System

MediLink is a comprehensive healthcare management system that provides services like appointment booking, drug information management, doctor listings, and medicine purchases.

## Database Setup Instructions

Follow these steps to set up the database for the MediLink application:

### Prerequisites
- MySQL Server (5.7 or higher)
- MySQL Workbench or phpMyAdmin
- PHP 7.4 or higher
- Web server (Apache, Nginx, etc.)

### Database Setup Steps

1. **Create the Database and Tables**
   - Open MySQL Workbench or phpMyAdmin
   - Execute the SQL script in the `medilink_database.sql` file
   - This will create the database, tables, and populate initial data

2. **Configure Database Connection**
   - Open the `php/config.php` file
   - Update the database credentials if needed:
     ```php
     $servername = "localhost"; // Change if your MySQL server is on a different host
     $username = "root";        // Change to your MySQL username
     $password = "12345";      // Change to your MySQL password
     $dbname = "medilink";      // Database name, leave as is unless you changed it
     ```

3. **Initialize Doctor Data**
   - After setting up the database and configuring the connection, run the doctor initialization script:
   - Access `http://your-server/php/init_doctors.php` in your browser
   - This will populate the doctors table with sample data for each medical category
   - You should see a confirmation message once doctors have been added successfully

4. **Set Up Web Server**
   - Place the entire project in your web server's document root
   - Make sure PHP is properly configured with your web server
   - Ensure the web server has write permissions to the project directory

## Troubleshooting

### Appointment Booking Issues
If you encounter an HTTP 405 error when booking appointments, check the following:
- Make sure your web server is properly configured to handle POST requests
- Verify that the `php/appointment.php` file has the correct permissions
- Check if there are any issues with the doctors table - run the initialization script if needed

### Database Connection Issues
- Double-check your database credentials in `php/config.php`
- Ensure MySQL server is running
- Check if the database has been created properly

## Project Structure

- `index.html` - Home page
- `login.html` - User login page
- `signup.html` - User registration page
- `cart.html` - Shopping cart
- `dims.html` - Drug Information Management System
- `doctors.html` - Doctors listing
- `blog.html` - Blog posts
- `php/` - Backend PHP files
  - `config.php` - Database configuration
  - `login.php` - Login handling
  - `signup.php` - User registration
  - `appointment.php` - Appointment booking
  - `cart.php` - Cart management
  - `dims.php` - Drug information retrieval
  - `doctors.php` - Doctor information
  - `blog.php` - Blog posts management
  - `medicines.php` - Medicine data handling
  - `contact.php` - Contact form handling
  - `logout.php` - User logout
  - `init_doctors.php` - Doctor data initialization script

## Features

- User registration and authentication
- Appointment booking with doctors
- Medicine browsing and purchasing
- Drug information lookup
- Shopping cart functionality
- Blog with healthcare articles

## Technology Stack

- Frontend: HTML, CSS, JavaScript
- Backend: PHP
- Database: MySQL

## Notes for Developers

- The project uses prepared statements for database queries to prevent SQL injection
- Session management is used for user authentication
- Form validation is performed on both client and server side 