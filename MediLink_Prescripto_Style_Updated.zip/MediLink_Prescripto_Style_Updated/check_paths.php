<?php
// Troubleshooting file - displays server information and current paths

// Display server information
echo "<h1>Server Information</h1>";
echo "<p><strong>PHP Version:</strong> " . phpversion() . "</p>";
echo "<p><strong>Server Software:</strong> " . $_SERVER['SERVER_SOFTWARE'] . "</p>";
echo "<p><strong>Document Root:</strong> " . $_SERVER['DOCUMENT_ROOT'] . "</p>";
echo "<p><strong>Current Script:</strong> " . $_SERVER['SCRIPT_FILENAME'] . "</p>";
echo "<p><strong>Script Name:</strong> " . $_SERVER['SCRIPT_NAME'] . "</p>";
echo "<p><strong>Request URI:</strong> " . $_SERVER['REQUEST_URI'] . "</p>";

// Check if the php directory exists
echo "<h2>Directory Check</h2>";
$phpDir = __DIR__ . '/php';
if (file_exists($phpDir) && is_dir($phpDir)) {
    echo "<p style='color:green'>PHP directory exists at: $phpDir</p>";
    
    // List files in the php directory
    echo "<h3>Files in PHP directory:</h3>";
    echo "<ul>";
    $files = scandir($phpDir);
    foreach ($files as $file) {
        if ($file != '.' && $file != '..') {
            echo "<li>$file";
            if (is_file("$phpDir/$file")) {
                echo " - File exists";
                if (is_readable("$phpDir/$file")) {
                    echo ", is readable";
                } else {
                    echo ", <span style='color:red'>NOT readable</span>";
                }
            }
            echo "</li>";
        }
    }
    echo "</ul>";
    
    // Specifically check for signup.php
    if (file_exists("$phpDir/signup.php")) {
        echo "<p style='color:green'>signup.php exists</p>";
    } else {
        echo "<p style='color:red'>signup.php does NOT exist in the php directory</p>";
    }
} else {
    echo "<p style='color:red'>PHP directory does NOT exist at: $phpDir</p>";
}

// List all directories in the current directory
echo "<h2>All Directories in Current Directory</h2>";
echo "<ul>";
$dirs = array_filter(glob(__DIR__ . '/*'), 'is_dir');
foreach ($dirs as $dir) {
    echo "<li>" . basename($dir) . "</li>";
}
echo "</ul>";

// List all PHP files in the current directory
echo "<h2>PHP Files in Current Directory</h2>";
echo "<ul>";
$phpFiles = glob(__DIR__ . '/*.php');
foreach ($phpFiles as $file) {
    echo "<li>" . basename($file) . "</li>";
}
echo "</ul>";

// Check for .htaccess file
if (file_exists(__DIR__ . '/.htaccess')) {
    echo "<p>Found .htaccess file in current directory</p>";
} else {
    echo "<p>No .htaccess file found in current directory</p>";
}

echo "<h2>Test Creating PHP File</h2>";
$testFile = __DIR__ . '/test_write.txt';
$result = file_put_contents($testFile, "Test write access at " . date('Y-m-d H:i:s'));
if ($result !== false) {
    echo "<p style='color:green'>Successfully wrote to test file</p>";
    unlink($testFile); // Clean up
} else {
    echo "<p style='color:red'>Could NOT write to test file</p>";
}
?> 