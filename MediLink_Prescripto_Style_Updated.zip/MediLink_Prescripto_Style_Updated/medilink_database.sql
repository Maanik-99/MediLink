-- MediLink Database Schema
-- Run this script in MySQL Workbench to create the database and tables

CREATE DATABASE IF NOT EXISTS medilink;
USE medilink;

-- Users table for login/signup
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    user_type ENUM('patient', 'doctor', 'admin') DEFAULT 'patient',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Categories table for medical specialties
CREATE TABLE categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(50) NOT NULL,
    description TEXT
);

-- Doctors table
CREATE TABLE doctors (
    doctor_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    name VARCHAR(100) NOT NULL,
    category_id INT,
    available_days VARCHAR(100),
    profile_image VARCHAR(255),
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (category_id) REFERENCES categories(category_id)
);

-- Appointments table
CREATE TABLE appointments (
    appointment_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT,
    doctor_id INT,
    appointment_date DATE NOT NULL,
    appointment_time TIME NOT NULL,
    status ENUM('pending', 'confirmed', 'cancelled', 'completed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES users(user_id),
    FOREIGN KEY (doctor_id) REFERENCES doctors(doctor_id)
);

-- Medicines table
CREATE TABLE medicines (
    medicine_id INT AUTO_INCREMENT PRIMARY KEY,
    medicine_name VARCHAR(100) NOT NULL,
    uses TEXT,
    side_effects TEXT,
    price DECIMAL(10,2) NOT NULL,
    image_path VARCHAR(255),
    stock_quantity INT DEFAULT 0
);

-- Cart items table
CREATE TABLE cart_items (
    cart_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    medicine_id INT,
    quantity INT DEFAULT 1,
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (medicine_id) REFERENCES medicines(medicine_id)
);

-- Orders table
CREATE TABLE orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    total_amount DECIMAL(10,2) NOT NULL,
    status ENUM('pending', 'processing', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Order items table
CREATE TABLE order_items (
    order_item_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT,
    medicine_id INT,
    quantity INT DEFAULT 1,
    price_per_unit DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (medicine_id) REFERENCES medicines(medicine_id)
);

-- Blog posts table
CREATE TABLE blog_posts (
    post_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    author_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (author_id) REFERENCES users(user_id)
);

-- Populate categories table with initial data
INSERT INTO categories (category_name, description) VALUES
('Cardiology', 'Deals with disorders of the heart and blood vessels'),
('Dermatology', 'Focuses on the diagnosis and treatment of skin disorders'),
('Neurology', 'Deals with disorders of the nervous system'),
('Pediatrics', 'Medical care of infants, children, and adolescents'),
('Orthopedics', 'Focuses on the musculoskeletal system'),
('General Surgery', 'Focuses on abdominal contents including the esophagus, stomach, small intestine, large intestine, liver, pancreas, gallbladder, appendix and bile ducts'),
('Gynecology', 'The branch of medicine that deals with the health of the female reproductive systems'),
('ENT', 'Otolaryngology - deals with the ear, nose, and throat'),
('Psychiatry', 'The medical specialty devoted to the diagnosis, prevention, and treatment of mental disorders'),
('Endocrinology', 'Deals with the endocrine system, its diseases, and its hormones');

-- Populate medicines table with initial data from the website
INSERT INTO medicines (medicine_name, uses, side_effects, price, image_path) VALUES
('Paracetamol', 'Pain relief, fever reduction.', 'Liver damage (overuse), allergic reactions.', 5.00, 'images/paracetamol.jpg'),
('Ibuprofen', 'Pain relief, anti-inflammatory, fever reduction.', 'Stomach upset, dizziness, ulcers, kidney damage (long-term use).', 7.00, 'images/Ibuprofen.jpg'),
('Amoxicillin', 'Antibiotic for bacterial infections.', 'Diarrhea, nausea, rash, allergic reactions.', 12.00, 'images/Amoxicillin.png'),
('Metformin', 'For managing type 2 diabetes.', 'Stomach upset, nausea, diarrhea, lactic acidosis (rare).', 15.00, 'images/Metformin.jpeg'),
('Lisinopril', 'For high blood pressure and heart failure.', 'Dizziness, cough, high potassium levels, kidney problems (rare).', 10.00, 'images/Lisinopril.jpeg'),
('Amlodipine', 'For high blood pressure and angina.', 'Swelling, dizziness, headache, low blood pressure.', 8.00, 'images/Amlodipine.jpeg'),
('Omeprazole', 'For acid reflux, GERD, ulcers.', 'Headache, diarrhea, nausea, kidney issues (rare).', 9.00, 'images/Omeprazole.jpg'),
('Simvastatin', 'For high cholesterol.', 'Muscle pain, liver damage (rare), digestive issues.', 11.00, 'images/Simvastatin'),
('Azithromycin', 'Antibiotic for various infections.', 'Diarrhea, nausea, abdominal pain, allergic reactions (rare).', 14.00, 'images/Azithromycin.jpg'),
('Hydrochlorothiazide', 'Diuretic for high blood pressure and fluid retention.', 'Increased urination, dizziness, dehydration, allergic reactions (rare).', 6.00, 'images/Hydrochlorothiazide.jpg'),
('Albuterol', 'For asthma and COPD.', 'Tremor, nervousness, headache, increased heart rate.', 13.00, 'images/Albuterol.jpg'),
('Gabapentin', 'For seizures and nerve pain.', 'Dizziness, drowsiness, swelling, mood changes.', 16.00, 'images/Gabapentin.jpg'),
('Sertraline', 'For depression, anxiety, OCD.', 'Nausea, sleep disturbances, sexual dysfunction, weight changes.', 18.00, 'images/Sertraline.jpg'),
('Furosemide', 'Diuretic for fluid retention and high blood pressure.', 'Increased urination, electrolyte imbalances, dizziness.', 7.50, 'images/Furosemide.jpg'),
('Prednisone', 'Anti-inflammatory for allergies, arthritis, and autoimmune disorders.', 'Weight gain, mood changes, increased blood sugar, bone loss.', 9.50, 'images/Prednisone.jpg'),
('Warfarin', 'Anticoagulant to prevent blood clots.', 'Bleeding, bruising, interactions with many drugs and foods.', 20.00, 'images/Warfarin.png'); 