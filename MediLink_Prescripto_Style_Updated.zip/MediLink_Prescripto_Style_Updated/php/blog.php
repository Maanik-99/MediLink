<?php
require_once 'config.php';

// Function to get all blog posts
function getAllBlogPosts() {
    global $conn;
    
    $query = "SELECT b.post_id, b.title, b.content, b.created_at, u.name as author_name
              FROM blog_posts b
              JOIN users u ON b.author_id = u.user_id
              ORDER BY b.created_at DESC";
    $result = $conn->query($query);
    
    $posts = [];
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // Create a truncated version of the content for preview
            $row['preview'] = substr(strip_tags($row['content']), 0, 200) . '...';
            $posts[] = $row;
        }
    }
    
    return $posts;
}

// Function to get a single blog post by ID
function getBlogPostById($postId) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT b.post_id, b.title, b.content, b.created_at, u.name as author_name
                           FROM blog_posts b
                           JOIN users u ON b.author_id = u.user_id
                           WHERE b.post_id = ?");
    $stmt->bind_param("i", $postId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result && $result->num_rows > 0) {
        $post = $result->fetch_assoc();
        $stmt->close();
        return $post;
    }
    
    $stmt->close();
    return null;
}

// Handle GET requests for blog data
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    header('Content-Type: application/json');
    
    // Check if a specific post ID is requested
    if (isset($_GET['post_id']) && !empty($_GET['post_id'])) {
        $postId = (int)$_GET['post_id'];
        $post = getBlogPostById($postId);
        
        if ($post) {
            echo json_encode(['success' => true, 'data' => $post]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Blog post not found']);
        }
    } else {
        // Return all blog posts
        $posts = getAllBlogPosts();
        echo json_encode(['success' => true, 'data' => $posts]);
    }
    
    exit;
}

// Handle POST requests to create a new blog post (admin only)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    session_start();
    
    // Check if user is logged in and is an admin
    if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || $_SESSION['user_type'] !== 'admin') {
        echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
        exit;
    }
    
    // Get form data
    $title = sanitize_input($_POST['title'] ?? '');
    $content = $_POST['content'] ?? '';
    $author_id = $_SESSION['user_id'];
    
    // Validate inputs
    if (empty($title) || empty($content)) {
        echo json_encode(['success' => false, 'message' => 'Title and content are required']);
        exit;
    }
    
    // Insert blog post
    $stmt = $conn->prepare("INSERT INTO blog_posts (title, content, author_id) VALUES (?, ?, ?)");
    $stmt->bind_param("ssi", $title, $content, $author_id);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Blog post created successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to create blog post: ' . $conn->error]);
    }
    
    $stmt->close();
    exit;
}
?> 