<?php
require_once 'config.php';

// Allow POST requests
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

// Function to get all doctors
function getAllDoctors() {
    global $conn;
    
    $query = "SELECT d.doctor_id, d.name, d.available_days, d.profile_image, c.category_name 
              FROM doctors d 
              JOIN categories c ON d.category_id = c.category_id 
              ORDER BY d.name";
    $result = $conn->query($query);
    
    $doctors = [];
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $doctors[] = $row;
        }
    }
    
    return $doctors;
}

// Function to get doctors by category
function getDoctorsByCategory($category) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT d.doctor_id, d.name, d.available_days, d.profile_image, c.category_name 
                           FROM doctors d 
                           JOIN categories c ON d.category_id = c.category_id 
                           WHERE c.category_name = ? 
                           ORDER BY d.name");
    $stmt->bind_param("s", $category);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $doctors = [];
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $doctors[] = $row;
        }
    }
    
    $stmt->close();
    return $doctors;
}

// Handle GET requests for doctor data
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    header('Content-Type: application/json');
    
    // Check if category filter is provided
    if (isset($_GET['category']) && !empty($_GET['category'])) {
        $category = sanitize_input($_GET['category']);
        $doctors = getDoctorsByCategory($category);
    } else {
        $doctors = getAllDoctors();
    }
    
    echo json_encode(['success' => true, 'data' => $doctors]);
    exit;
}

// Handle doctor booking request - POST method
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    
    // Check if it's a booking action
    if (isset($_POST['action']) && $_POST['action'] === 'book') {
        // Check if user is logged in
        session_start();
        if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
            echo json_encode(['success' => false, 'message' => 'Please log in to book an appointment']);
            exit;
        }
        
        $doctor_id = isset($_POST['doctor_id']) ? (int)$_POST['doctor_id'] : 0;
        $date = isset($_POST['date']) ? sanitize_input($_POST['date']) : '';
        $time = isset($_POST['time']) ? sanitize_input($_POST['time']) : '';
        $patient_id = $_SESSION['user_id'];
        
        // Validate inputs
        if ($doctor_id <= 0 || empty($date) || empty($time)) {
            echo json_encode(['success' => false, 'message' => 'Please provide all required information']);
            exit;
        }
        
        // Check if the date is not in the past
        $today = date("Y-m-d");
        if ($date < $today) {
            echo json_encode(['success' => false, 'message' => 'Appointment date cannot be in the past']);
            exit;
        }
        
        try {
            // Check if doctor exists
            $doctor_check = $conn->prepare("SELECT doctor_id FROM doctors WHERE doctor_id = ?");
            $doctor_check->bind_param("i", $doctor_id);
            $doctor_check->execute();
            $doctor_result = $doctor_check->get_result();
            
            if ($doctor_result->num_rows == 0) {
                echo json_encode(['success' => false, 'message' => 'Doctor not found']);
                exit;
            }
            
            // Insert appointment into database
            $stmt = $conn->prepare("INSERT INTO appointments (patient_id, doctor_id, appointment_date, appointment_time) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("iiss", $patient_id, $doctor_id, $date, $time);
            
            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'message' => 'Appointment booked successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to book appointment: ' . $conn->error]);
            }
            
            $stmt->close();
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
    }
    exit;
}

// Return error for unsupported methods
header('HTTP/1.1 405 Method Not Allowed');
header('Allow: GET, POST');
echo json_encode(['success' => false, 'message' => 'Method not allowed']);
exit;
?> 