<?php
session_start();
require_once 'config.php';

// Set header to JSON
header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'Please log in to view appointments']);
    exit();
}

// Get user ID from session
$user_id = $_SESSION['user_id'];

// Handle GET request to view appointments
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        // Get appointments for the logged-in user
        $query = "SELECT a.appointment_id, a.appointment_date, a.appointment_time, a.status, 
                d.name AS doctor_name, c.category_name 
                FROM appointments a
                JOIN doctors d ON a.doctor_id = d.doctor_id
                JOIN categories c ON d.category_id = c.category_id
                WHERE a.patient_id = ?
                ORDER BY a.appointment_date DESC, a.appointment_time ASC";
                
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $appointments = [];
        
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $appointments[] = $row;
            }
            echo json_encode(['success' => true, 'data' => $appointments]);
        } else {
            echo json_encode(['success' => true, 'data' => [], 'message' => 'No appointments found']);
        }
        
        $stmt->close();
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Error retrieving appointments: ' . $e->getMessage()]);
    }
    exit();
}

// Handle POST request to cancel/update appointment
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $action = isset($_POST['action']) ? sanitize_input($_POST['action']) : '';
    $appointment_id = isset($_POST['appointment_id']) ? (int)$_POST['appointment_id'] : 0;
    
    // Validate input
    if (empty($action) || $appointment_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid request parameters']);
        exit();
    }
    
    try {
        // Verify the appointment belongs to the user
        $stmt = $conn->prepare("SELECT appointment_id FROM appointments WHERE appointment_id = ? AND patient_id = ?");
        $stmt->bind_param("ii", $appointment_id, $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            echo json_encode(['success' => false, 'message' => 'Appointment not found or you do not have permission']);
            exit();
        }
        
        // Handle different actions
        if ($action === 'cancel') {
            $stmt = $conn->prepare("UPDATE appointments SET status = 'cancelled' WHERE appointment_id = ?");
            $stmt->bind_param("i", $appointment_id);
            
            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'message' => 'Appointment cancelled successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to cancel appointment: ' . $conn->error]);
            }
        } else if ($action === 'reschedule') {
            // Additional parameters needed for rescheduling
            $new_date = isset($_POST['date']) ? sanitize_input($_POST['date']) : '';
            $new_time = isset($_POST['time']) ? sanitize_input($_POST['time']) : '';
            
            // Validate new date and time
            if (empty($new_date) || empty($new_time)) {
                echo json_encode(['success' => false, 'message' => 'New date and time are required for rescheduling']);
                exit();
            }
            
            // Check if the date is not in the past
            $today = date("Y-m-d");
            if ($new_date < $today) {
                echo json_encode(['success' => false, 'message' => 'Appointment date cannot be in the past']);
                exit();
            }
            
            // Update appointment
            $stmt = $conn->prepare("UPDATE appointments SET appointment_date = ?, appointment_time = ?, status = 'pending' WHERE appointment_id = ?");
            $stmt->bind_param("ssi", $new_date, $new_time, $appointment_id);
            
            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'message' => 'Appointment rescheduled successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to reschedule appointment: ' . $conn->error]);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
        }
        
        $stmt->close();
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
    
    exit();
}

// Return error for unsupported methods
header('HTTP/1.1 405 Method Not Allowed');
header('Allow: GET, POST');
echo json_encode(['success' => false, 'message' => 'Method not allowed']);
exit();
?> 