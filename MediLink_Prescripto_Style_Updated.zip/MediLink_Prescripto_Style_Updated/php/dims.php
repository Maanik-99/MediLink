<?php
require_once 'config.php';

// Function to get all medicines
function getAllMedicines() {
    global $conn;
    
    $query = "SELECT medicine_id, medicine_name, uses, side_effects FROM medicines ORDER BY medicine_name";
    $result = $conn->query($query);
    
    $medicines = [];
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $medicines[] = $row;
        }
    }
    
    return $medicines;
}

// Function to search medicines
function searchMedicines($searchTerm) {
    global $conn;
    
    $searchTerm = "%$searchTerm%";
    
    $stmt = $conn->prepare("SELECT medicine_id, medicine_name, uses, side_effects 
                          FROM medicines 
                          WHERE medicine_name LIKE ? 
                          ORDER BY medicine_name");
    $stmt->bind_param("s", $searchTerm);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $medicines = [];
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $medicines[] = $row;
        }
    }
    
    $stmt->close();
    return $medicines;
}

// Handle AJAX requests for medicine data
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    header('Content-Type: application/json');
    
    // Check if search term is provided
    if (isset($_GET['search']) && !empty($_GET['search'])) {
        $searchTerm = sanitize_input($_GET['search']);
        $medicines = searchMedicines($searchTerm);
    } else {
        $medicines = getAllMedicines();
    }
    
    echo json_encode(['success' => true, 'data' => $medicines]);
    exit;
}
?> 