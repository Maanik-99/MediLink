<?php
session_start();

// Set content type to JSON
header('Content-Type: application/json');

// Check if user is logged in
$logged_in = isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true;

// Return login status
echo json_encode([
    'logged_in' => $logged_in,
    'user_id' => $logged_in ? $_SESSION['user_id'] : null,
    'user_name' => $logged_in ? $_SESSION['name'] : null,
    'user_type' => $logged_in ? $_SESSION['user_type'] : null
]);
?> 