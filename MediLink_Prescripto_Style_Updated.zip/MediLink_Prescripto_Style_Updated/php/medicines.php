<?php
require_once 'config.php';

// Function to get all medicines
function getAllMedicines() {
    global $conn;
    
    $query = "SELECT medicine_id, medicine_name, uses, side_effects, price, image_path, stock_quantity 
              FROM medicines 
              ORDER BY medicine_name";
    $result = $conn->query($query);
    
    $medicines = [];
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $medicines[] = $row;
        }
    }
    
    return $medicines;
}

// Function to get a single medicine by ID
function getMedicineById($medicineId) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT medicine_id, medicine_name, uses, side_effects, price, image_path, stock_quantity 
                           FROM medicines 
                           WHERE medicine_id = ?");
    $stmt->bind_param("i", $medicineId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result && $result->num_rows > 0) {
        $medicine = $result->fetch_assoc();
        $stmt->close();
        return $medicine;
    }
    
    $stmt->close();
    return null;
}

// Function to search medicines by name
function searchMedicines($searchTerm) {
    global $conn;
    
    $searchTerm = "%$searchTerm%";
    
    $stmt = $conn->prepare("SELECT medicine_id, medicine_name, uses, side_effects, price, image_path, stock_quantity 
                           FROM medicines 
                           WHERE medicine_name LIKE ? 
                           ORDER BY medicine_name");
    $stmt->bind_param("s", $searchTerm);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $medicines = [];
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $medicines[] = $row;
        }
    }
    
    $stmt->close();
    return $medicines;
}

// Handle requests for medicine data
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    header('Content-Type: application/json');
    
    // Check if a specific medicine ID is requested
    if (isset($_GET['medicine_id']) && !empty($_GET['medicine_id'])) {
        $medicineId = (int)$_GET['medicine_id'];
        $medicine = getMedicineById($medicineId);
        
        if ($medicine) {
            echo json_encode(['success' => true, 'data' => $medicine]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Medicine not found']);
        }
    }
    // Check if search term is provided
    else if (isset($_GET['search']) && !empty($_GET['search'])) {
        $searchTerm = sanitize_input($_GET['search']);
        $medicines = searchMedicines($searchTerm);
        echo json_encode(['success' => true, 'data' => $medicines]);
    }
    // Return all medicines
    else {
        $medicines = getAllMedicines();
        echo json_encode(['success' => true, 'data' => $medicines]);
    }
    
    exit;
}
?> 