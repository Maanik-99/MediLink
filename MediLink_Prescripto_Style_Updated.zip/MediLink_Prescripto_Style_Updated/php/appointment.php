<?php
session_start();
require_once 'config.php';

// Allow POST requests
header('Access-Control-Allow-Methods: POST');

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    // Set message and redirect to login
    $_SESSION['message'] = "Please log in to book an appointment";
    header("Location: ../login.html");
    exit();
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = sanitize_input($_POST['name']);
    $email = sanitize_input($_POST['email']);
    $category = sanitize_input($_POST['category']);
    $date = sanitize_input($_POST['date']);
    $time = sanitize_input($_POST['time']);
    
    // Get user ID from session
    $patient_id = $_SESSION['user_id'];
    
    // Validate inputs
    $errors = [];
    
    if (empty($name)) {
        $errors[] = "Name is required";
    }
    
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "A valid email is required";
    }
    
    if (empty($category)) {
        $errors[] = "Please select a medical category";
    }
    
    if (empty($date)) {
        $errors[] = "Please select an appointment date";
    }
    
    if (empty($time)) {
        $errors[] = "Please select an appointment time";
    }
    
    // Check if the date is not in the past
    $today = date("Y-m-d");
    if ($date < $today) {
        $errors[] = "Appointment date cannot be in the past";
    }
    
    // If no errors, proceed to book appointment
    if (empty($errors)) {
        try {
            // Find a doctor in the selected category
            $stmt = $conn->prepare("SELECT doctor_id FROM doctors WHERE category_id = (SELECT category_id FROM categories WHERE category_name = ?) LIMIT 1");
            $stmt->bind_param("s", $category);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows == 1) {
                $row = $result->fetch_assoc();
                $doctor_id = $row['doctor_id'];
                
                // Insert appointment into database
                $stmt = $conn->prepare("INSERT INTO appointments (patient_id, doctor_id, appointment_date, appointment_time) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("iiss", $patient_id, $doctor_id, $date, $time);
                
                if ($stmt->execute()) {
                    // Set success message
                    $_SESSION['success_message'] = "Appointment booked successfully!";
                    header("Location: ../index.html");
                    exit();
                } else {
                    $errors[] = "Failed to book appointment: " . $conn->error;
                }
            } else {
                // If no doctor is found in the selected category
                // First, check if the category exists
                $stmt = $conn->prepare("SELECT category_id FROM categories WHERE category_name = ?");
                $stmt->bind_param("s", $category);
                $stmt->execute();
                $category_result = $stmt->get_result();
                
                if ($category_result->num_rows == 0) {
                    $errors[] = "Selected category does not exist in the database";
                } else {
                    // If category exists but no doctor, make a dummy entry
                    $cat_row = $category_result->fetch_assoc();
                    $category_id = $cat_row['category_id'];
                    
                    // First create a doctor for this category
                    $doctor_name = "Dr. Default for " . $category;
                    $stmt = $conn->prepare("INSERT INTO doctors (name, category_id, available_days) VALUES (?, ?, 'Mon-Fri')");
                    $stmt->bind_param("si", $doctor_name, $category_id);
                    $stmt->execute();
                    $doctor_id = $conn->insert_id;
                    
                    // Now create the appointment
                    $stmt = $conn->prepare("INSERT INTO appointments (patient_id, doctor_id, appointment_date, appointment_time) VALUES (?, ?, ?, ?)");
                    $stmt->bind_param("iiss", $patient_id, $doctor_id, $date, $time);
                    
                    if ($stmt->execute()) {
                        // Set success message
                        $_SESSION['success_message'] = "Appointment booked successfully!";
                        header("Location: ../index.html");
                        exit();
                    } else {
                        $errors[] = "Failed to book appointment: " . $conn->error;
                    }
                }
            }
            $stmt->close();
        } catch (Exception $e) {
            $errors[] = "Error: " . $e->getMessage();
        }
    }
    
    // If there are errors, store them in session and redirect back
    if (!empty($errors)) {
        $_SESSION['appointment_errors'] = $errors;
        header("Location: ../index.html#appointmentForm");
        exit();
    }
} else {
    // Return error for non-POST requests
    header('HTTP/1.1 405 Method Not Allowed');
    header('Allow: POST');
    echo 'This endpoint only accepts POST requests';
    exit();
}
?> 