<?php
// One-time script to initialize doctor data
require_once 'config.php';

// Check if doctors already exist
$result = $conn->query("SELECT COUNT(*) as count FROM doctors");
$row = $result->fetch_assoc();

if ($row['count'] > 0) {
    echo "Doctors already exist in the database. To repopulate, please truncate the doctors table first.";
    exit;
}

// Array of sample doctor data
$doctors = [
    ['Dr. Farhan Rahman', 'Cardiology', 'Mon-Wed', 'images/doctor1.jpg'],
    ['Dr. Aminul Islam', 'Dermatology', 'Thu-Sat', 'images/doctor2.jpg'],
    ['Dr. Rakib Hossain', 'Neurology', 'Mon-Fri', 'images/doctor3.jpg'],
    ['Dr. Saad Ahmed', 'Pediatrics', 'Tue-Thu', 'images/doctor4.jpg'],
    ['Dr. Tanvir Ahmed', 'Orthopedics', 'Mon-Wed', 'images/doctor6.png'],
    ['Dr. Nazmul Hossain', 'General Surgery', 'Thu-Sat', 'images/doctor6.png'],
    ['Dr. Rumana Sultana', 'Gynecology', 'Mon-Fri', 'images/dr_rumana_sultana.jpg'],
    ['Dr. Shahriar Hossain', 'ENT', 'Tue-Thu', 'images/dr_shahriar_hossain.jpg'],
    ['Dr. Mamun Ahmed', 'Psychiatry', 'Mon-Wed', 'images/dr_mamun_ahmed.jpg'],
    ['Dr. Fahmida Khatun', 'Endocrinology', 'Thu-Sat', 'images/dr_fahmida_khatun.jpg']
];

// Start transaction
$conn->begin_transaction();

try {
    // Check that categories exist
    $result = $conn->query("SELECT COUNT(*) as count FROM categories");
    $row = $result->fetch_assoc();
    
    if ($row['count'] == 0) {
        echo "Categories not found. Please run the initial database setup first.";
        exit;
    }
    
    // Prepare statement for inserting doctors
    $stmt = $conn->prepare("INSERT INTO doctors (name, category_id, available_days, profile_image) 
                           VALUES (?, (SELECT category_id FROM categories WHERE category_name = ?), ?, ?)");
    
    foreach ($doctors as $doctor) {
        $stmt->bind_param("ssss", $doctor[0], $doctor[1], $doctor[2], $doctor[3]);
        $stmt->execute();
        echo "Added doctor: " . $doctor[0] . " (" . $doctor[1] . ")<br>";
    }
    
    // Commit transaction
    $conn->commit();
    echo "Successfully added " . count($doctors) . " doctors to the database!";
    
} catch (Exception $e) {
    // Roll back if error
    $conn->rollback();
    echo "Error: " . $e->getMessage();
}
?> 