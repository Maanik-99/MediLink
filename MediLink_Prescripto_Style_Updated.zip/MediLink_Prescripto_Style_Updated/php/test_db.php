<?php
// Database connection test file

// Database credentials from config
$servername = "localhost";
$username = "root"; 
$password = "12345"; 
$dbname = "medilink";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

echo "Database connection successful!";

// Check if the users table exists
$result = $conn->query("SHOW TABLES LIKE 'users'");
if ($result->num_rows > 0) {
    echo "<br>Users table exists.";
    
    // Count users in the table
    $result = $conn->query("SELECT COUNT(*) as count FROM users");
    $row = $result->fetch_assoc();
    echo "<br>Number of users in database: " . $row['count'];
} else {
    echo "<br>Users table does not exist. Please run the database setup script.";
}

// Close connection
$conn->close();
?> 