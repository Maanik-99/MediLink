<?php
// Include database configuration
require_once 'config.php';

// Set content type to JSON
header('Content-Type: application/json');

// Get all medicines from the database
$sql = "SELECT medicine_id, medicine_name, description, price, image_path, stock_quantity 
        FROM medicines 
        ORDER BY medicine_name ASC";

$result = $conn->query($sql);

if ($result) {
    $medicines = [];
    
    // Fetch all medicines
    while ($row = $result->fetch_assoc()) {
        $medicines[] = [
            'medicine_id' => $row['medicine_id'],
            'medicine_name' => $row['medicine_name'],
            'description' => $row['description'],
            'price' => $row['price'],
            'image_path' => $row['image_path'],
            'stock_quantity' => $row['stock_quantity']
        ];
    }
    
    // Return success with medicines data
    echo json_encode([
        'success' => true,
        'medicines' => $medicines
    ]);
} else {
    // Return error if query fails
    echo json_encode([
        'success' => false,
        'message' => 'Failed to load medicines: ' . $conn->error
    ]);
}

// Close connection
$conn->close();
?> 