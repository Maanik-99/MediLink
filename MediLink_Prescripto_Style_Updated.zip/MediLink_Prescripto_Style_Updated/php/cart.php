<?php
session_start();
require_once 'config.php';

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    // Return JSON response for AJAX calls
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        echo json_encode(['success' => false, 'message' => 'You must be logged in to perform this action']);
        exit;
    }
    
    // Standard redirect for direct access
    $_SESSION['message'] = "Please log in to access your cart";
    header("Location: ../login.html");
    exit();
}

// Get user ID from session
$user_id = $_SESSION['user_id'];

// Handle different cart operations
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check the operation type
    $operation = isset($_POST['operation']) ? sanitize_input($_POST['operation']) : '';
    
    // Add item to cart
    if ($operation == 'add') {
        $medicine_id = isset($_POST['medicine_id']) ? (int)$_POST['medicine_id'] : 0;
        $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
        
        if ($medicine_id <= 0 || $quantity <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid product or quantity']);
            exit;
        }
        
        // Check if item already exists in cart
        $stmt = $conn->prepare("SELECT cart_id, quantity FROM cart_items WHERE user_id = ? AND medicine_id = ?");
        $stmt->bind_param("ii", $user_id, $medicine_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            // Item exists, update quantity
            $row = $result->fetch_assoc();
            $new_quantity = $row['quantity'] + $quantity;
            
            $update_stmt = $conn->prepare("UPDATE cart_items SET quantity = ? WHERE cart_id = ?");
            $update_stmt->bind_param("ii", $new_quantity, $row['cart_id']);
            $success = $update_stmt->execute();
            $update_stmt->close();
        } else {
            // Item doesn't exist, insert new
            $insert_stmt = $conn->prepare("INSERT INTO cart_items (user_id, medicine_id, quantity) VALUES (?, ?, ?)");
            $insert_stmt->bind_param("iii", $user_id, $medicine_id, $quantity);
            $success = $insert_stmt->execute();
            $insert_stmt->close();
        }
        
        if ($success) {
            echo json_encode(['success' => true, 'message' => 'Item added to cart']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to add item to cart']);
        }
        $stmt->close();
    }
    
    // Update cart item quantity
    else if ($operation == 'update') {
        $cart_id = isset($_POST['cart_id']) ? (int)$_POST['cart_id'] : 0;
        $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
        
        if ($cart_id <= 0 || $quantity <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid cart item or quantity']);
            exit;
        }
        
        // Update the quantity
        $stmt = $conn->prepare("UPDATE cart_items SET quantity = ? WHERE cart_id = ? AND user_id = ?");
        $stmt->bind_param("iii", $quantity, $cart_id, $user_id);
        $success = $stmt->execute();
        $stmt->close();
        
        if ($success) {
            echo json_encode(['success' => true, 'message' => 'Cart updated']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to update cart']);
        }
    }
    
    // Remove item from cart
    else if ($operation == 'remove') {
        $cart_id = isset($_POST['cart_id']) ? (int)$_POST['cart_id'] : 0;
        
        if ($cart_id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid cart item']);
            exit;
        }
        
        // Delete the item
        $stmt = $conn->prepare("DELETE FROM cart_items WHERE cart_id = ? AND user_id = ?");
        $stmt->bind_param("ii", $cart_id, $user_id);
        $success = $stmt->execute();
        $stmt->close();
        
        if ($success) {
            echo json_encode(['success' => true, 'message' => 'Item removed from cart']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to remove item from cart']);
        }
    }
    
    // Clear entire cart
    else if ($operation == 'clear') {
        $stmt = $conn->prepare("DELETE FROM cart_items WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        $success = $stmt->execute();
        $stmt->close();
        
        if ($success) {
            echo json_encode(['success' => true, 'message' => 'Cart cleared']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to clear cart']);
        }
    }
    
    // Checkout
    else if ($operation == 'checkout') {
        // Begin transaction
        $conn->begin_transaction();
        
        try {
            // Get cart items
            $stmt = $conn->prepare("SELECT c.medicine_id, c.quantity, m.price FROM cart_items c 
                                   JOIN medicines m ON c.medicine_id = m.medicine_id 
                                   WHERE c.user_id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows == 0) {
                echo json_encode(['success' => false, 'message' => 'Your cart is empty']);
                exit;
            }
            
            // Calculate total
            $total_amount = 0;
            $cart_items = [];
            
            while ($row = $result->fetch_assoc()) {
                $cart_items[] = $row;
                $total_amount += $row['quantity'] * $row['price'];
            }
            
            // Create order
            $stmt = $conn->prepare("INSERT INTO orders (user_id, total_amount) VALUES (?, ?)");
            $stmt->bind_param("id", $user_id, $total_amount);
            $stmt->execute();
            $order_id = $conn->insert_id;
            
            // Add order items
            $stmt = $conn->prepare("INSERT INTO order_items (order_id, medicine_id, quantity, price_per_unit) VALUES (?, ?, ?, ?)");
            
            foreach ($cart_items as $item) {
                $stmt->bind_param("iiid", $order_id, $item['medicine_id'], $item['quantity'], $item['price']);
                $stmt->execute();
            }
            
            // Clear cart
            $stmt = $conn->prepare("DELETE FROM cart_items WHERE user_id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            
            // Commit transaction
            $conn->commit();
            
            echo json_encode(['success' => true, 'message' => 'Order placed successfully', 'order_id' => $order_id]);
        } catch (Exception $e) {
            // Rollback if error occurs
            $conn->rollback();
            echo json_encode(['success' => false, 'message' => 'An error occurred while processing your order: ' . $e->getMessage()]);
        }
    }
    
    exit;
}

// GET request - Return cart data
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    try {
        // Log the request
        error_log("Cart data requested for user_id: $user_id");
        
        // Get cart items with product info
        $stmt = $conn->prepare("SELECT c.cart_id, c.medicine_id, c.quantity, c.added_at, 
                               m.medicine_name, m.price, m.image_path
                               FROM cart_items c 
                               JOIN medicines m ON c.medicine_id = m.medicine_id 
                               WHERE c.user_id = ?
                               ORDER BY c.added_at DESC");
        
        if (!$stmt) {
            throw new Exception("Prepare statement failed: " . $conn->error);
        }
        
        $stmt->bind_param("i", $user_id);
        
        if (!$stmt->execute()) {
            throw new Exception("Execute failed: " . $stmt->error);
        }
        
        $result = $stmt->get_result();
        
        $cart_items = [];
        $total = 0;
        
        while ($row = $result->fetch_assoc()) {
            $item_total = $row['quantity'] * $row['price'];
            $total += $item_total;
            
            // Fix image path - use a relative path that works in the browser
            $image_path = 'images/medicine-placeholder.jpg'; // Default fallback
            
            if (!empty($row['image_path'])) {
                $image_path = $row['image_path'];
                // Ensure path doesn't have problematic leading slashes for relative URLs
                $image_path = ltrim($image_path, '/');
            }
            
            $cart_items[] = [
                'cart_id' => $row['cart_id'],
                'medicine_id' => $row['medicine_id'],
                'name' => $row['medicine_name'],
                'quantity' => $row['quantity'],
                'price' => (float)$row['price'],
                'image' => $image_path,
                'item_total' => (float)$item_total,
                'added_at' => $row['added_at']
            ];
        }
        
        echo json_encode([
            'success' => true,
            'cart_items' => $cart_items,
            'total' => (float)$total,
            'item_count' => count($cart_items)
        ]);
        
        $stmt->close();
    } catch (Exception $e) {
        // Log the error
        error_log("Cart error: " . $e->getMessage());
        
        // Return error to client
        echo json_encode([
            'success' => false,
            'message' => 'Error retrieving cart items: ' . $e->getMessage()
        ]);
    }
    exit;
}
?> 