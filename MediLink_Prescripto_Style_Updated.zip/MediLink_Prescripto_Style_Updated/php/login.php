<?php
session_start();
require_once 'config.php';

// Set allowed methods
header('Access-Control-Allow-Methods: POST');

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $email = sanitize_input($_POST['email']);
    $password = $_POST['password'];
    $user_type = isset($_POST['user_type']) ? sanitize_input($_POST['user_type']) : '';
    
    // Validation
    $errors = [];
    
    // Check if email is valid
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "A valid email is required";
    }
    
    // Check if password is not empty
    if (empty($password)) {
        $errors[] = "Password is required";
    }
    
    // Check if user type is not empty
    if (empty($user_type)) {
        $errors[] = "User type is required";
    }
    
    // If no validation errors, attempt login
    if (empty($errors)) {
        try {
            // Log login attempt
            error_log("Login attempt for email: $email with user type: $user_type");
            
            // Query database for user with matching email and user type
            $stmt = $conn->prepare("SELECT user_id, name, email, password, user_type FROM users WHERE email = ? AND user_type = ?");
            if (!$stmt) {
                throw new Exception("Prepare statement failed: " . $conn->error);
            }
            
            $stmt->bind_param("ss", $email, $user_type);
            if (!$stmt->execute()) {
                throw new Exception("Execute failed: " . $stmt->error);
            }
            
            $result = $stmt->get_result();
            
            if ($result->num_rows == 1) {
                $user = $result->fetch_assoc();
                
                // Compare plain text passwords directly
                if ($password === $user['password']) {
                    // Password is correct, set session variables
                    $_SESSION['logged_in'] = true;
                    $_SESSION['user_id'] = $user['user_id'];
                    $_SESSION['name'] = $user['name'];
                    $_SESSION['email'] = $user['email'];
                    $_SESSION['user_type'] = $user['user_type'];
                    
                    // Log successful login
                    error_log("Login successful for: $email");
                    
                    // Set content type for JSON response
                    header('Content-Type: application/json');
                    
                    // Redirect all users to index.html for now
                    echo json_encode(['success' => true, 'redirect' => 'index.html']);
                    exit();
                } else {
                    $errors[] = "Invalid password";
                    error_log("Invalid password for email: $email");
                }
            } else {
                $errors[] = "Invalid email or user type";
                error_log("User not found for email: $email with user type: $user_type");
            }
            $stmt->close();
        } catch (Exception $e) {
            error_log("Login error: " . $e->getMessage());
            $errors[] = "Login error: " . $e->getMessage();
        }
    }
    
    // If there are errors, return them as JSON
    if (!empty($errors)) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'errors' => $errors]);
        exit();
    }
} else {
    // Return error for non-POST requests
    header('HTTP/1.1 405 Method Not Allowed');
    header('Allow: POST');
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'errors' => ['Method not allowed. Please use the login form.']]);
    exit();
}
?> 