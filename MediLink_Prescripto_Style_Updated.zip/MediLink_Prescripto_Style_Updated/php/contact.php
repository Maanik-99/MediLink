<?php
session_start();
require_once 'config.php';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = sanitize_input($_POST['name'] ?? '');
    $email = sanitize_input($_POST['email'] ?? '');
    $subject = sanitize_input($_POST['subject'] ?? '');
    $message = sanitize_input($_POST['message'] ?? '');
    
    // Validate inputs
    $errors = [];
    
    if (empty($name)) {
        $errors[] = "Name is required";
    }
    
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "A valid email is required";
    }
    
    if (empty($subject)) {
        $errors[] = "Subject is required";
    }
    
    if (empty($message)) {
        $errors[] = "Message is required";
    }
    
    // If no errors, process the form
    if (empty($errors)) {
        // In a real-world application, you might:
        // 1. Save to database
        // 2. Send an email notification
        // 3. Both of the above
        
        // For this example, we'll just set a success message
        $_SESSION['contact_success'] = "Thank you for your message. We will get back to you soon!";
        
        // Optional: Log or email the contact request
        $to = "admin@medilink.com"; // Replace with your email
        $email_subject = "MediLink Contact: $subject";
        $email_body = "You have received a new message from the MediLink contact form.\n\n"
            . "Name: $name\n"
            . "Email: $email\n"
            . "Subject: $subject\n"
            . "Message:\n$message";
        $headers = "From: noreply@medilink.com";
        
        // Uncomment the following line to actually send an email in production
        // mail($to, $email_subject, $email_body, $headers);
        
        // AJAX response or redirect
        if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
            echo json_encode(['success' => true, 'message' => 'Thank you for your message. We will get back to you soon!']);
            exit;
        } else {
            // Redirect to contact page
            header("Location: ../contact.html");
            exit;
        }
    }
    
    // If there are errors, return them
    if (!empty($errors)) {
        if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
            echo json_encode(['success' => false, 'errors' => $errors]);
            exit;
        } else {
            $_SESSION['contact_errors'] = $errors;
            header("Location: ../contact.html");
            exit;
        }
    }
}
?> 