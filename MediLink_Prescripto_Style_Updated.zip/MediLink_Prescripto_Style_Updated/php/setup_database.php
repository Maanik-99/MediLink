<?php
// Database setup script

// Database credentials
$servername = "localhost";
$username = "root";
$password = "12345";
$dbname = "medilink";

// Create connection without database selection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "Connected to MySQL server successfully.<br>";

// Check if database exists, create if not
$result = $conn->query("SHOW DATABASES LIKE '$dbname'");
if ($result->num_rows == 0) {
    echo "Database '$dbname' does not exist. Creating database...<br>";
    if ($conn->query("CREATE DATABASE $dbname")) {
        echo "Database created successfully.<br>";
    } else {
        die("Error creating database: " . $conn->error);
    }
} else {
    echo "Database '$dbname' already exists.<br>";
}

// Select the database
$conn->select_db($dbname);

// Check if users table exists, create if not
$result = $conn->query("SHOW TABLES LIKE 'users'");
if ($result->num_rows == 0) {
    echo "Table 'users' does not exist. Creating table...<br>";
    
    $sql = "CREATE TABLE users (
        user_id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        user_type ENUM('patient', 'doctor', 'admin') DEFAULT 'patient',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    if ($conn->query($sql)) {
        echo "Table 'users' created successfully.<br>";
    } else {
        die("Error creating table: " . $conn->error);
    }
} else {
    echo "Table 'users' already exists.<br>";
}

// Check if categories table exists, create if not
$result = $conn->query("SHOW TABLES LIKE 'categories'");
if ($result->num_rows == 0) {
    echo "Table 'categories' does not exist. Creating table...<br>";
    
    $sql = "CREATE TABLE categories (
        category_id INT AUTO_INCREMENT PRIMARY KEY,
        category_name VARCHAR(50) NOT NULL,
        description TEXT
    )";
    
    if ($conn->query($sql)) {
        echo "Table 'categories' created successfully.<br>";
        
        // Insert default categories
        $sql = "INSERT INTO categories (category_name, description) VALUES
            ('Cardiology', 'Deals with disorders of the heart and blood vessels'),
            ('Dermatology', 'Focuses on the diagnosis and treatment of skin disorders'),
            ('Neurology', 'Deals with disorders of the nervous system'),
            ('Pediatrics', 'Medical care of infants, children, and adolescents'),
            ('Orthopedics', 'Focuses on the musculoskeletal system'),
            ('General Surgery', 'Focuses on abdominal contents including the esophagus, stomach, small intestine, large intestine, liver, pancreas, gallbladder, appendix and bile ducts'),
            ('Gynecology', 'The branch of medicine that deals with the health of the female reproductive systems'),
            ('ENT', 'Otolaryngology - deals with the ear, nose, and throat'),
            ('Psychiatry', 'The medical specialty devoted to the diagnosis, prevention, and treatment of mental disorders'),
            ('Endocrinology', 'Deals with the endocrine system, its diseases, and its hormones')";
        
        if ($conn->query($sql)) {
            echo "Default categories inserted successfully.<br>";
        } else {
            echo "Error inserting default categories: " . $conn->error . "<br>";
        }
    } else {
        die("Error creating table: " . $conn->error);
    }
} else {
    echo "Table 'categories' already exists.<br>";
}

// Check if doctors table exists, create if not
$result = $conn->query("SHOW TABLES LIKE 'doctors'");
if ($result->num_rows == 0) {
    echo "Table 'doctors' does not exist. Creating table...<br>";
    
    $sql = "CREATE TABLE doctors (
        doctor_id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        name VARCHAR(100) NOT NULL,
        category_id INT,
        available_days VARCHAR(100),
        profile_image VARCHAR(255),
        FOREIGN KEY (user_id) REFERENCES users(user_id),
        FOREIGN KEY (category_id) REFERENCES categories(category_id)
    )";
    
    if ($conn->query($sql)) {
        echo "Table 'doctors' created successfully.<br>";
    } else {
        die("Error creating table: " . $conn->error);
    }
} else {
    echo "Table 'doctors' already exists.<br>";
}

// Check if appointments table exists, create if not
$result = $conn->query("SHOW TABLES LIKE 'appointments'");
if ($result->num_rows == 0) {
    echo "Table 'appointments' does not exist. Creating table...<br>";
    
    $sql = "CREATE TABLE appointments (
        appointment_id INT AUTO_INCREMENT PRIMARY KEY,
        patient_id INT,
        doctor_id INT,
        appointment_date DATE NOT NULL,
        appointment_time TIME NOT NULL,
        status ENUM('pending', 'confirmed', 'cancelled', 'completed') DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (patient_id) REFERENCES users(user_id),
        FOREIGN KEY (doctor_id) REFERENCES doctors(doctor_id)
    )";
    
    if ($conn->query($sql)) {
        echo "Table 'appointments' created successfully.<br>";
    } else {
        die("Error creating table: " . $conn->error);
    }
} else {
    echo "Table 'appointments' already exists.<br>";
}

// Check if medicines table exists, create if not
$result = $conn->query("SHOW TABLES LIKE 'medicines'");
if ($result->num_rows == 0) {
    echo "Table 'medicines' does not exist. Creating table...<br>";
    
    $sql = "CREATE TABLE medicines (
        medicine_id INT AUTO_INCREMENT PRIMARY KEY,
        medicine_name VARCHAR(100) NOT NULL,
        description TEXT,
        price DECIMAL(10, 2) NOT NULL,
        image_path VARCHAR(255),
        stock_quantity INT DEFAULT 100,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    if ($conn->query($sql)) {
        echo "Table 'medicines' created successfully.<br>";
        
        // Insert sample medicines
        $medicines = [
            ['Paracetamol', 'Pain reliever for mild to moderate pain', 5.00, 'images/paracetamol.jpg'],
            ['Ibuprofen', 'Anti-inflammatory medication', 7.00, 'images/Ibuprofen.jpg'],
            ['Amoxicillin', 'Antibiotic for bacterial infections', 12.00, 'images/Amoxicillin.png'],
            ['Metformin', 'For type 2 diabetes', 15.00, 'images/Metformin.jpeg'],
            ['Lisinopril', 'For high blood pressure', 10.00, 'images/Lisinopril.jpeg'],
            ['Amlodipine', 'Calcium channel blocker for hypertension', 8.00, 'images/Amlodipine.jpeg'],
            ['Omeprazole', 'For acid reflux and ulcers', 9.00, 'images/Omeprazole.jpg'],
            ['Simvastatin', 'For high cholesterol', 11.00, 'images/Simvastatin'],
            ['Azithromycin', 'Antibiotic for infections', 14.00, 'images/Azithromycin.jpg'],
            ['Hydrochlorothiazide', 'Diuretic for high blood pressure', 6.00, 'images/Hydrochlorothiazide.jpg'],
            ['Albuterol', 'For asthma and COPD', 13.00, 'images/Albuterol.jpg'],
            ['Gabapentin', 'For nerve pain and seizures', 16.00, 'images/Gabapentin.jpg'],
            ['Sertraline', 'For depression and anxiety', 18.00, 'images/Sertraline.jpg'],
            ['Furosemide', 'Diuretic for fluid retention', 7.50, 'images/Furosemide.jpg'],
            ['Prednisone', 'Corticosteroid for inflammation', 9.50, 'images/Prednisone.jpg']
        ];
        
        $stmt = $conn->prepare("INSERT INTO medicines (medicine_name, description, price, image_path) VALUES (?, ?, ?, ?)");
        
        foreach ($medicines as $medicine) {
            $stmt->bind_param("ssds", $medicine[0], $medicine[1], $medicine[2], $medicine[3]);
            $stmt->execute();
        }
        
        $stmt->close();
        echo "Sample medicines added successfully.<br>";
    } else {
        die("Error creating medicines table: " . $conn->error);
    }
} else {
    echo "Table 'medicines' already exists.<br>";
}

// Check if cart_items table exists, create if not
$result = $conn->query("SHOW TABLES LIKE 'cart_items'");
if ($result->num_rows == 0) {
    echo "Table 'cart_items' does not exist. Creating table...<br>";
    
    $sql = "CREATE TABLE cart_items (
        cart_id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        medicine_id INT NOT NULL,
        quantity INT NOT NULL DEFAULT 1,
        added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(user_id),
        FOREIGN KEY (medicine_id) REFERENCES medicines(medicine_id)
    )";
    
    if ($conn->query($sql)) {
        echo "Table 'cart_items' created successfully.<br>";
    } else {
        die("Error creating cart_items table: " . $conn->error);
    }
} else {
    echo "Table 'cart_items' already exists.<br>";
}

// Check if orders table exists, create if not
$result = $conn->query("SHOW TABLES LIKE 'orders'");
if ($result->num_rows == 0) {
    echo "Table 'orders' does not exist. Creating table...<br>";
    
    $sql = "CREATE TABLE orders (
        order_id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        total_amount DECIMAL(10, 2) NOT NULL,
        status ENUM('pending', 'processing', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(user_id)
    )";
    
    if ($conn->query($sql)) {
        echo "Table 'orders' created successfully.<br>";
    } else {
        die("Error creating orders table: " . $conn->error);
    }
} else {
    echo "Table 'orders' already exists.<br>";
}

// Check if order_items table exists, create if not
$result = $conn->query("SHOW TABLES LIKE 'order_items'");
if ($result->num_rows == 0) {
    echo "Table 'order_items' does not exist. Creating table...<br>";
    
    $sql = "CREATE TABLE order_items (
        order_item_id INT AUTO_INCREMENT PRIMARY KEY,
        order_id INT NOT NULL,
        medicine_id INT NOT NULL,
        quantity INT NOT NULL,
        price_per_unit DECIMAL(10, 2) NOT NULL,
        FOREIGN KEY (order_id) REFERENCES orders(order_id),
        FOREIGN KEY (medicine_id) REFERENCES medicines(medicine_id)
    )";
    
    if ($conn->query($sql)) {
        echo "Table 'order_items' created successfully.<br>";
    } else {
        die("Error creating order_items table: " . $conn->error);
    }
} else {
    echo "Table 'order_items' already exists.<br>";
}

// Test user creation
echo "<h3>Testing User Registration</h3>";
echo "Attempting to create a test user...<br>";

// Create test user
$testName = "Test User";
$testEmail = "test@example.com";
$testPassword = "password123";
// Store plain text password instead of hashing
$plainPassword = $testPassword;

// Check if the test user already exists
$stmt = $conn->prepare("SELECT email FROM users WHERE email = ?");
$stmt->bind_param("s", $testEmail);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    // Insert test user
    $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $testName, $testEmail, $plainPassword);
    
    if ($stmt->execute()) {
        echo "Test user created successfully.<br>";
        echo "Email: $testEmail<br>";
        echo "Password: $testPassword<br>";
    } else {
        echo "Error creating test user: " . $stmt->error . "<br>";
    }
} else {
    echo "Test user already exists.<br>";
}

$stmt->close();

// Close connection
$conn->close();

echo "<h3>Database setup complete!</h3>";
echo "<p>You can now <a href='../signup.html'>sign up</a> or <a href='../login.html'>log in</a>.</p>";
?> 