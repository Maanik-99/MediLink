<?php
// Database connection configuration

// Database credentials
$servername = "localhost";
$username = "root"; // Default MySQL username, change in production
$password = "12345"; // Default empty password, change in production
$dbname = "medilink";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset to ensure proper handling of special characters
$conn->set_charset("utf8mb4");

// Helper function to sanitize user inputs
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Redirect helper function
function redirect($url) {
    header("Location: $url");
    exit;
}

// Alert message function
function set_message($message) {
    $_SESSION['message'] = $message;
}

// Get alert message function
function get_message() {
    if(isset($_SESSION['message'])) {
        $message = $_SESSION['message'];
        unset($_SESSION['message']);
        return $message;
    }
    return "";
}
?> 