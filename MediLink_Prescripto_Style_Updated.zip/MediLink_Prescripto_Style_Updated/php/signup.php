<?php
session_start();
require_once 'config.php';

// Set headers to allow only POST method
header('Access-Control-Allow-Methods: POST');

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data and sanitize
    $name = sanitize_input($_POST['name']);
    $email = sanitize_input($_POST['email']);
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];
    $user_type = isset($_POST['user_type']) ? sanitize_input($_POST['user_type']) : 'patient';
    
    // Validation
    $errors = [];
    
    // Check if name is not empty
    if (empty($name)) {
        $errors[] = "Name is required";
    }
    
    // Check if email is valid
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "A valid email is required";
    }
    
    // Check if password is at least 6 characters
    if (strlen($password) < 6) {
        $errors[] = "Password must be at least 6 characters";
    }
    
    // Check if passwords match
    if ($password !== $confirmPassword) {
        $errors[] = "Passwords do not match";
    }
    
    // Validate user type
    $allowed_types = ['patient', 'doctor', 'admin'];
    if (!in_array($user_type, $allowed_types)) {
        $errors[] = "Invalid user type selected";
    }
    
    // Check if email already exists
    $stmt = $conn->prepare("SELECT email FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $errors[] = "Email already registered. Please use a different email or login.";
    }
    $stmt->close();
    
    // If no errors, proceed with registration
    if (empty($errors)) {
        // Store plain text password instead of hashing
        $password_plain = $password;
        
        // Insert user into database
        $stmt = $conn->prepare("INSERT INTO users (name, email, password, user_type) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $email, $password_plain, $user_type);
        
        if ($stmt->execute()) {
            // Set success message and redirect to login page
            $_SESSION['success_message'] = "Registration successful! You can now log in.";
            header("Location: ../login.html");
            exit();
        } else {
            $errors[] = "Registration failed: " . $conn->error;
        }
        $stmt->close();
    }
    
    // If there are errors, return them as JSON
    if (!empty($errors)) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'errors' => $errors]);
        exit();
    }
} else {
    // Return error for non-POST requests
    header('HTTP/1.1 405 Method Not Allowed');
    header('Allow: POST');
    echo 'This endpoint only accepts POST requests. Please use the signup form.';
    exit();
}
?> 