console.log("Welcome to MediLink (Prescripto-style)");

let slideIndex = 0;
showSlides();

function showSlides() {
  let i;
  let slides = document.getElementsByClassName("slideshow-slide");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}
  slides[slideIndex-1].style.display = "block";
  setTimeout(showSlides, 4000); // Change image every 4 seconds
}

document.querySelector('.prev').addEventListener('click', function() {
  plusSlides(-1);
});

document.querySelector('.next').addEventListener('click', function() {
  plusSlides(1);
});

function plusSlides(n) {
  slideIndex += n - 1;
  if (slideIndex < 0) {
    slideIndex = document.getElementsByClassName("slideshow-slide").length - 1;
  }
  showSlides();
}
document.addEventListener('DOMContentLoaded', function () {
  const buyButtons = document.querySelectorAll('.product-item button');
  buyButtons.forEach(function(button) {
    button.addEventListener('click', function() {
      const productName = this.parentElement.querySelector('h3').textContent;
      let quantity = prompt("How many do you want to buy?", "1");
      quantity = parseInt(quantity, 10);
      if (isNaN(quantity) || quantity < 1) {
        alert("Please enter a valid quantity.");
        return;
      }
      let cart = JSON.parse(localStorage.getItem('cart')) || [];
      const now = Date.now();
      // Check if product already in cart
      const existing = cart.find(item => item.name === productName);
      if (existing) {
        existing.quantity += quantity;
        existing.time = now; // update time to last added
      } else {
        cart.push({ name: productName, quantity: quantity, time: now });
      }
      localStorage.setItem('cart', JSON.stringify(cart));
      // Update cart count
      const cartCountSpan = document.getElementById('cart-count');
      if (cartCountSpan) cartCountSpan.textContent = cart.reduce((sum, item) => sum + item.quantity, 0);
      alert(productName + " (" + quantity + ") added to cart!");
    });
  });
});

document.getElementById('buy-selected-btn').addEventListener('click', function() {
  const selected = Array.from(document.querySelectorAll('.select-item:checked'))
    .map(cb => cart[parseInt(cb.getAttribute('data-idx'), 10)]);
  if (selected.length === 0) {
    alert('Please select at least one item to buy.');
    return;
  }
  // Here you can process the selected items (e.g., send to server)
  alert('You have bought:\n' + selected.map(item => `${item.name} (x${item.quantity})`).join('\n'));
  // Optionally, remove bought items from cart:
  // cart = cart.filter((item, idx) => !document.querySelector(`.select-item[data-idx="${idx}"]`).checked);
  // localStorage.setItem('cart', JSON.stringify(cart));
  // renderCart();
});
// Appointment form submission handler (basic)
document.getElementById('appointmentForm').addEventListener('submit', function(e) {
  e.preventDefault();
  alert('Appointment booked successfully!');
  this.reset();
});

// Check if user is logged in and update navigation
document.addEventListener('DOMContentLoaded', function() {
  // Function to check login status
  function checkLoginStatus() {
    fetch('php/check_login.php')
      .then(response => response.json())
      .then(data => {
        updateNavigation(data.logged_in);
      })
      .catch(error => {
        console.error('Error checking login status:', error);
      });
  }
  
  // Function to update navigation based on login status
  function updateNavigation(isLoggedIn) {
    const navLinks = document.querySelector('.nav-links');
    if (!navLinks) return;
    
    // Find login and signup links
    const loginLink = navLinks.querySelector('a[href="login.html"]');
    const signupLink = navLinks.querySelector('a[href="signup.html"]');
    const appointmentsLink = navLinks.querySelector('a[href="appointments.html"]');
    
    if (isLoggedIn) {
      // User is logged in
      if (loginLink) {
        const loginLi = loginLink.parentElement;
        loginLi.innerHTML = '<a href="php/logout.php">Logout</a>';
      }
      
      if (signupLink) {
        const signupLi = signupLink.parentElement;
        signupLi.innerHTML = '<a href="#">My Profile</a>';
      }
      
      // Make sure appointments link is visible
      if (appointmentsLink) {
        appointmentsLink.parentElement.style.display = 'block';
      }
    } else {
      // User is not logged in
      if (loginLink) {
        const loginLi = loginLink.parentElement;
        loginLi.innerHTML = '<a href="login.html">Login</a>';
      }
      
      if (signupLink) {
        const signupLi = signupLink.parentElement;
        signupLi.innerHTML = '<a href="signup.html">Sign Up</a>';
      }
      
      // Hide appointments link for non-logged in users
      if (appointmentsLink) {
        appointmentsLink.parentElement.style.display = 'none';
      }
    }
  }
  
  // Call the function to check login status when page loads
  checkLoginStatus();
});
