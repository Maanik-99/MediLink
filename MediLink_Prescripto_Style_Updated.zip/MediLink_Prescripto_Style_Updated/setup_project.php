<?php
// Project setup and verification script

echo "<h1>MediLink Project Setup</h1>";

// Check if php directory exists, create if needed
$phpDir = __DIR__ . '/php';
if (!file_exists($phpDir)) {
    echo "<p>Creating PHP directory...</p>";
    if (mkdir($phpDir, 0755)) {
        echo "<p style='color:green'>PHP directory created successfully</p>";
    } else {
        echo "<p style='color:red'>Failed to create PHP directory</p>";
    }
} else {
    echo "<p>PHP directory already exists</p>";
}

// List of essential PHP files that should be in the php directory
$phpFiles = [
    'signup.php' => '<?php
session_start();
require_once \'config.php\';

// Set headers to allow only POST method
header(\'Access-Control-Allow-Methods: POST\');

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data and sanitize
    $name = sanitize_input($_POST[\'name\']);
    $email = sanitize_input($_POST[\'email\']);
    $password = $_POST[\'password\'];
    $confirmPassword = $_POST[\'confirmPassword\'];
    
    // Validation
    $errors = [];
    
    // Check if name is not empty
    if (empty($name)) {
        $errors[] = "Name is required";
    }
    
    // Check if email is valid
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "A valid email is required";
    }
    
    // Check if password is at least 6 characters
    if (strlen($password) < 6) {
        $errors[] = "Password must be at least 6 characters";
    }
    
    // Check if passwords match
    if ($password !== $confirmPassword) {
        $errors[] = "Passwords do not match";
    }
    
    // Check if email already exists
    $stmt = $conn->prepare("SELECT email FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $errors[] = "Email already registered. Please use a different email or login.";
    }
    $stmt->close();
    
    // If no errors, proceed with registration
    if (empty($errors)) {
        // Hash the password
        $password_hash = password_hash($password, PASSWORD_DEFAULT);
        
        // Insert user into database
        $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $email, $password_hash);
        
        if ($stmt->execute()) {
            // Set success message and redirect to login page
            $_SESSION[\'success_message\'] = "Registration successful! You can now log in.";
            header("Location: ../login.html");
            exit();
        } else {
            $errors[] = "Registration failed: " . $conn->error;
        }
        $stmt->close();
    }
    
    // If there are errors, return them as JSON
    if (!empty($errors)) {
        header(\'Content-Type: application/json\');
        echo json_encode([\'success\' => false, \'errors\' => $errors]);
        exit();
    }
} else {
    // Return error for non-POST requests
    header(\'HTTP/1.1 405 Method Not Allowed\');
    header(\'Allow: POST\');
    echo \'This endpoint only accepts POST requests. Please use the signup form.\';
    exit();
}
?>',
    'login.php' => '<?php
session_start();
require_once \'config.php\';

// Set allowed methods
header(\'Access-Control-Allow-Methods: POST\');

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $email = sanitize_input($_POST[\'email\']);
    $password = $_POST[\'password\'];
    
    // Validation
    $errors = [];
    
    // Check if email is valid
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "A valid email is required";
    }
    
    // Check if password is not empty
    if (empty($password)) {
        $errors[] = "Password is required";
    }
    
    // If no validation errors, attempt login
    if (empty($errors)) {
        // Query database for user
        $stmt = $conn->prepare("SELECT user_id, name, email, password, user_type FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();
            
            // Verify password
            if (password_verify($password, $user[\'password\'])) {
                // Password is correct, set session variables
                $_SESSION[\'logged_in\'] = true;
                $_SESSION[\'user_id\'] = $user[\'user_id\'];
                $_SESSION[\'name\'] = $user[\'name\'];
                $_SESSION[\'email\'] = $user[\'email\'];
                $_SESSION[\'user_type\'] = $user[\'user_type\'];
                
                // Set content type for JSON response
                header(\'Content-Type: application/json\');
                
                // Redirect based on user type
                if ($user[\'user_type\'] == \'admin\') {
                    echo json_encode([\'success\' => true, \'redirect\' => \'../admin/dashboard.php\']);
                } else {
                    echo json_encode([\'success\' => true, \'redirect\' => \'../index.html\']);
                }
                exit();
            } else {
                $errors[] = "Invalid password";
            }
        } else {
            $errors[] = "Email not found";
        }
        $stmt->close();
    }
    
    // If there are errors, return them as JSON
    if (!empty($errors)) {
        header(\'Content-Type: application/json\');
        echo json_encode([\'success\' => false, \'errors\' => $errors]);
        exit();
    }
} else {
    // Return error for non-POST requests
    header(\'HTTP/1.1 405 Method Not Allowed\');
    header(\'Allow: POST\');
    echo \'This endpoint only accepts POST requests. Please use the login form.\';
    exit();
}
?>',
    'config.php' => '<?php
// Database connection configuration

// Database credentials
$servername = "localhost";
$username = "root"; // Default MySQL username, change in production
$password = "12345"; // Default empty password, change in production
$dbname = "medilink";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset to ensure proper handling of special characters
$conn->set_charset("utf8mb4");

// Helper function to sanitize user inputs
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Redirect helper function
function redirect($url) {
    header("Location: $url");
    exit;
}

// Alert message function
function set_message($message) {
    $_SESSION[\'message\'] = $message;
}

// Get alert message function
function get_message() {
    if(isset($_SESSION[\'message\'])) {
        $message = $_SESSION[\'message\'];
        unset($_SESSION[\'message\']);
        return $message;
    }
    return "";
}
?>',
    'setup_database.php' => '<?php
// Database setup script

// Database credentials
$servername = "localhost";
$username = "root";
$password = "12345";
$dbname = "medilink";

// Create connection without database selection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "Connected to MySQL server successfully.<br>";

// Check if database exists, create if not
$result = $conn->query("SHOW DATABASES LIKE \'$dbname\'");
if ($result->num_rows == 0) {
    echo "Database \'$dbname\' does not exist. Creating database...<br>";
    if ($conn->query("CREATE DATABASE $dbname")) {
        echo "Database created successfully.<br>";
    } else {
        die("Error creating database: " . $conn->error);
    }
} else {
    echo "Database \'$dbname\' already exists.<br>";
}

// Select the database
$conn->select_db($dbname);

// Check if users table exists, create if not
$result = $conn->query("SHOW TABLES LIKE \'users\'");
if ($result->num_rows == 0) {
    echo "Table \'users\' does not exist. Creating table...<br>";
    
    $sql = "CREATE TABLE users (
        user_id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        user_type ENUM(\'patient\', \'doctor\', \'admin\') DEFAULT \'patient\',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    if ($conn->query($sql)) {
        echo "Table \'users\' created successfully.<br>";
    } else {
        die("Error creating table: " . $conn->error);
    }
} else {
    echo "Table \'users\' already exists.<br>";
}

// Create test user
$testName = "Test User";
$testEmail = "test@example.com";
$testPassword = "password123";
$hashedPassword = password_hash($testPassword, PASSWORD_DEFAULT);

// Check if the test user already exists
$stmt = $conn->prepare("SELECT email FROM users WHERE email = ?");
$stmt->bind_param("s", $testEmail);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    // Insert test user
    $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $testName, $testEmail, $hashedPassword);
    
    if ($stmt->execute()) {
        echo "Test user created successfully.<br>";
        echo "Email: $testEmail<br>";
        echo "Password: $testPassword<br>";
    } else {
        echo "Error creating test user: " . $stmt->error . "<br>";
    }
} else {
    echo "Test user already exists.<br>";
}

$stmt->close();
$conn->close();

echo "<h3>Database setup complete!</h3>";
echo "<p>You can now <a href=\'../signup.html\'>sign up</a> or <a href=\'../login.html\'>log in</a>.</p>";
?>'
];

// Create or update PHP files
foreach ($phpFiles as $filename => $content) {
    $filePath = "$phpDir/$filename";
    
    // Check if file needs to be created or updated
    if (!file_exists($filePath)) {
        echo "<p>Creating $filename...</p>";
        if (file_put_contents($filePath, $content)) {
            echo "<p style='color:green'>$filename created successfully</p>";
        } else {
            echo "<p style='color:red'>Failed to create $filename</p>";
        }
    } else {
        echo "<p>$filename already exists. Ensuring it's up to date...</p>";
        if (file_put_contents($filePath, $content)) {
            echo "<p style='color:green'>$filename updated successfully</p>";
        } else {
            echo "<p style='color:red'>Failed to update $filename</p>";
        }
    }
}

// Check file permissions
echo "<h2>Checking File Permissions</h2>";
foreach ($phpFiles as $filename => $content) {
    $filePath = "$phpDir/$filename";
    if (file_exists($filePath)) {
        echo "<p>$filename: ";
        echo is_readable($filePath) ? "Readable, " : "NOT readable, ";
        echo is_writable($filePath) ? "Writable" : "NOT writable";
        echo "</p>";
    }
}

echo "<h2>Summary</h2>";
echo "<p>Project setup completed. You now have:</p>";
echo "<ul>";
echo "<li>PHP directory with all necessary files</li>";
echo "<li>Database configuration file</li>";
echo "<li>Setup script for database creation</li>";
echo "<li>Login and signup handlers</li>";
echo "</ul>";

echo "<p>Next steps:</p>";
echo "<ol>";
echo "<li>Run <a href='php/setup_database.php'>setup_database.php</a> to create the database and tables</li>";
echo "<li>Try to <a href='signup.html'>sign up</a> a new user</li>";
echo "<li>Or <a href='login.html'>log in</a> with the test user (test@example.com / password123)</li>";
echo "</ol>";
?> 