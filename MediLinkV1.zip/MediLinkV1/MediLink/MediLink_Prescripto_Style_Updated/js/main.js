console.log("Welcome to MediLink (Prescripto-style)");

let slideIndex = 0;
showSlides();

function showSlides() {
  let i;
  let slides = document.getElementsByClassName("slideshow-slide");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}
  slides[slideIndex-1].style.display = "block";
  setTimeout(showSlides, 4000); // Change image every 4 seconds
}

document.querySelector('.prev').addEventListener('click', function() {
  plusSlides(-1);
});

document.querySelector('.next').addEventListener('click', function() {
  plusSlides(1);
});

function plusSlides(n) {
  slideIndex += n - 1;
  if (slideIndex < 0) {
    slideIndex = document.getElementsByClassName("slideshow-slide").length - 1;
  }
  showSlides();
}
document.addEventListener('DOMContentLoaded', function () {
  const buyButtons = document.querySelectorAll('.product-item button');
  buyButtons.forEach(function(button) {
    button.addEventListener('click', function() {
      const productName = this.parentElement.querySelector('h3').textContent;
      let quantity = prompt("How many do you want to buy?", "1");
      quantity = parseInt(quantity, 10);
      if (isNaN(quantity) || quantity < 1) {
        alert("Please enter a valid quantity.");
        return;
      }
      let cart = JSON.parse(localStorage.getItem('cart')) || [];
      const now = Date.now();
      // Check if product already in cart
      const existing = cart.find(item => item.name === productName);
      if (existing) {
        existing.quantity += quantity;
        existing.time = now; // update time to last added
      } else {
        cart.push({ name: productName, quantity: quantity, time: now });
      }
      localStorage.setItem('cart', JSON.stringify(cart));
      // Update cart count
      const cartCountSpan = document.getElementById('cart-count');
      if (cartCountSpan) cartCountSpan.textContent = cart.reduce((sum, item) => sum + item.quantity, 0);
      alert(productName + " (" + quantity + ") added to cart!");
    });
  });
});

document.getElementById('buy-selected-btn').addEventListener('click', function() {
  const selected = Array.from(document.querySelectorAll('.select-item:checked'))
    .map(cb => cart[parseInt(cb.getAttribute('data-idx'), 10)]);
  if (selected.length === 0) {
    alert('Please select at least one item to buy.');
    return;
  }
  // Here you can process the selected items (e.g., send to server)
  alert('You have bought:\n' + selected.map(item => `${item.name} (x${item.quantity})`).join('\n'));
  // Optionally, remove bought items from cart:
  // cart = cart.filter((item, idx) => !document.querySelector(`.select-item[data-idx="${idx}"]`).checked);
  // localStorage.setItem('cart', JSON.stringify(cart));
  // renderCart();
});
// Appointment form submission handler (basic)
document.getElementById('appointmentForm').addEventListener('submit', function(e) {
  e.preventDefault();
  alert('Appointment booked successfully!');
  this.reset();
});
