<?php
session_start();
$conn = new mysqli("localhost", "root", "", "medilink");
if ($conn->connect_error) { die("Connection failed"); }

$email = trim($_POST['email']);
$password = $_POST['password'];

$stmt = $conn->prepare("SELECT id, name, password FROM users WHERE email=?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows === 1) {
    $stmt->bind_result($id, $name, $hash);
    $stmt->fetch();
    if (password_verify($password, $hash)) {
        $_SESSION['user_id'] = $id;
        $_SESSION['user_name'] = $name;
        echo "success";
    } else {
        echo "Invalid credentials.";
    }
} else {
    echo "Invalid credentials.";
}
$stmt->close();
$conn->close();
?>