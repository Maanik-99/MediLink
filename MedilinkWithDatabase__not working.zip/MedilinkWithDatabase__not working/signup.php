<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "medilink";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Database connection failed.");
}

$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

if (!$name || !$email || !$password) {
    echo "Please fill in all fields.";
    exit;
}

$hashed = password_hash($password, PASSWORD_DEFAULT);

// Check for duplicate email
$check = $conn->prepare("SELECT id FROM users WHERE email = ?");
$check->bind_param("s", $email);
$check->execute();
$check->store_result();
if ($check->num_rows > 0) {
    echo "Email already exists.";
    $check->close();
    $conn->close();
    exit;
}
$check->close();

// Insert user
$stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $name, $email, $hashed);
if ($stmt->execute()) {
    echo "success";
} else {
    echo "Error: " . $stmt->error;
}
$stmt->close();
$conn->close();
?>
