<?php
session_start();
if (!isset($_SESSION['user_id'])) { header("Location: login.html"); exit; }
$conn = new mysqli("localhost", "root", "", "medilink");
if ($conn->connect_error) { die("Connection failed"); }

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dob = $_POST['dob'];
    $occupation = $_POST['occupation'];
    $about = $_POST['about'];
    $stmt = $conn->prepare("UPDATE users SET dob=?, occupation=?, about=? WHERE id=?");
    $stmt->bind_param("sssi", $dob, $occupation, $about, $user_id);
    $stmt->execute();
    $stmt->close();
    echo "Profile updated!";
}

$stmt = $conn->prepare("SELECT name, email, dob, occupation, about FROM users WHERE id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($name, $email, $dob, $occupation, $about);
$stmt->fetch();
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
  <title>User Profile</title>
</head>
<body>
  <h2>Welcome, <?php echo htmlspecialchars($name); ?></h2>
  <form method="post">
    Email: <b><?php echo htmlspecialchars($email); ?></b><br>
    DOB: <input type="date" name="dob" value="<?php echo htmlspecialchars($dob); ?>"><br>
    Occupation: <input type="text" name="occupation" value="<?php echo htmlspecialchars($occupation); ?>"><br>
    About: <textarea name="about"><?php echo htmlspecialchars($about); ?></textarea><br>
    <button type="submit">Update Profile</button>
  </form>
  <a href="reset_password.html">Reset Password</a> | <a href="logout.php">Logout</a>
</body>
</html>